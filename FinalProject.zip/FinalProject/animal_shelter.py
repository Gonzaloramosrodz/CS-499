# animal_shelter.py — hardened & rubric-ready (DB + security) for CS 499
# - No hardcoded secrets; supports MONGO_URI or host/port/user/pass via env
# - Full CRUD with ObjectId validation and structured returns
# - Safe query allowlist sanitizer for MongoDB operators
# - Basic input validation (rejects $-prefixed keys in docs)
# - Aggregations, pagination, sorting, projection
# - Helpful indexes created on common fields

from __future__ import annotations

import os
import logging
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.collection import Collection
from pymongo.errors import PyMongoError
from bson.objectid import ObjectId

# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# -----------------------------------------------------------------------------
# Constants & Allowlists
# -----------------------------------------------------------------------------
ALLOWED_OPERATORS: set = {
    "$and", "$or", "$nor",
    "$eq", "$ne", "$gt", "$gte", "$lt", "$lte",
    "$in", "$nin",
    "$exists", "$regex", "$not"
}

DEFAULT_PAGE_SIZE = 25
MAX_PAGE_SIZE = 200

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def _str_object_id(value: Union[str, ObjectId]) -> ObjectId:
    if isinstance(value, ObjectId):
        return value
    if not ObjectId.is_valid(value):
        raise ValueError("Invalid ObjectId")
    return ObjectId(value)

def _reject_dollar_keys(doc: Dict[str, Any]) -> None:
    """
    Prevent operator injection in documents used for create/update.
    """
    for k, v in doc.items():
        if isinstance(k, str) and k.startswith("$"):
            raise ValueError(f"Illegal key '{k}' in document payload.")
        if isinstance(v, dict):
            _reject_dollar_keys(v)
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    _reject_dollar_keys(item)

def _sanitize_filter(expr: Any) -> Any:
    """
    Recursively sanitize a filter expression:
      - Allow only recognized Mongo operators.
      - Field names cannot start with '$'.
    """
    if isinstance(expr, dict):
        cleaned: Dict[str, Any] = {}
        for key, val in expr.items():
            if key.startswith("$"):
                # operator
                if key not in ALLOWED_OPERATORS:
                    # strip unknown operator
                    logger.warning("Stripped unknown operator: %s", key)
                    continue
                cleaned[key] = _sanitize_filter(val)
            else:
                # field name
                if not isinstance(key, str):
                    continue
                cleaned[key] = _sanitize_filter(val)
        return cleaned
    elif isinstance(expr, list):
        return [_sanitize_filter(x) for x in expr]
    else:
        return expr

def _coerce_sort(sort: Optional[Iterable[Tuple[str, Union[int, str]]]]) -> Optional[List[Tuple[str, int]]]:
    """
    Coerce incoming sort spec to PyMongo format.
    Accepts [('field', ASCENDING|DESCENDING|1|-1 | 'asc'|'desc'), ...]
    """
    if not sort:
        return None
    out: List[Tuple[str, int]] = []
    for fld, direction in sort:
        if isinstance(direction, str):
            d = direction.lower()
            val = ASCENDING if d in ("asc", "ascending", "1") else DESCENDING
        else:
            val = ASCENDING if int(direction) >= 0 else DESCENDING
        out.append((fld, val))
    return out

# -----------------------------------------------------------------------------
# AnimalShelter
# -----------------------------------------------------------------------------
class AnimalShelter:
    """CRUD + analytics for the AAC animals collection in MongoDB."""

    def __init__(
        self,
        *,
        mongo_uri: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        db_name: Optional[str] = None,
        collection_name: Optional[str] = None,
    ):
        """
        Connection precedence:
          1) mongo_uri (arg or env MONGO_URI)
          2) host/port/username/password/db/collection from args or env
        Env vars (if not passing args):
          MONGO_URI
          MONGO_HOST, MONGO_PORT, MONGO_USER, MONGO_PASS
          MONGO_DB (default: 'AAC'), MONGO_COL (default: 'animals')
        """
        # Pull from env as needed
        mongo_uri = mongo_uri or os.getenv("MONGO_URI")

        host = host or os.getenv("MONGO_HOST")
        port = port or int(os.getenv("MONGO_PORT", "0") or 0)
        username = username or os.getenv("MONGO_USER")
        password = password or os.getenv("MONGO_PASS")
        db_name = db_name or os.getenv("MONGO_DB", "AAC")
        collection_name = collection_name or os.getenv("MONGO_COL", "animals")

        try:
            if mongo_uri:
                self.client = MongoClient(mongo_uri)
            else:
                # Require essentials if not using URI
                if not (host and port and username and password):
                    raise ValueError("Missing Mongo connection parameters (host/port/user/pass) or MONGO_URI.")
                self.client = MongoClient(
                    host=host,
                    port=int(port),
                    username=username,
                    password=password,
                )

            self.database = self.client[db_name]
            self.collection: Collection = self.database[collection_name]
            logger.info("Connected to MongoDB [%s.%s].", db_name, collection_name)

            self._ensure_indexes()
        except Exception as e:
            logger.error("MongoDB connection failed: %s", e)
            raise

    # -------------------------------------------------------------------------
    # Indexes
    # -------------------------------------------------------------------------
    def _ensure_indexes(self) -> None:
        """
        Create helpful indexes for common queries.
        """
        try:
            self.collection.create_index([("breed", ASCENDING)])
            self.collection.create_index([("outcome_type", ASCENDING)])
            self.collection.create_index([("age_upon_outcome_in_weeks", DESCENDING)])
        except PyMongoError as e:
            logger.warning("Index creation warning: %s", e)

    # -------------------------------------------------------------------------
    # CRUD
    # -------------------------------------------------------------------------
    def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Insert a new document. Returns a structured envelope.
        """
        if not isinstance(data, dict) or not data:
            raise ValueError("Data must be a non-empty dict.")

        _reject_dollar_keys(data)

        try:
            result = self.collection.insert_one(data)
            return {"ok": True, "id": str(result.inserted_id)}
        except PyMongoError as e:
            logger.error("Create failed: %s", e)
            return {"ok": False, "error": str(e)}

    def read(
        self,
        query: Dict[str, Any] | None = None,
        *,
        limit: int = 100,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[Iterable[Tuple[str, Union[int, str]]]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Read documents with optional projection & sorting. Returns a list.
        """
        q = _sanitize_filter(query or {})
        if limit <= 0:
            limit = 100

        try:
            cursor = self.collection.find(q, projection=projection)
            if sort:
                cursor = cursor.sort(_coerce_sort(sort))
            cursor = cursor.limit(limit)
            docs = list(cursor)
            for d in docs:
                d["_id"] = str(d["_id"])
            return docs
        except PyMongoError as e:
            logger.error("Read failed: %s", e)
            return []

    def read_paginated(
        self,
        query: Dict[str, Any] | None = None,
        *,
        page: int = 1,
        page_size: int = DEFAULT_PAGE_SIZE,
        projection: Optional[Dict[str, int]] = None,
        sort: Optional[Iterable[Tuple[str, Union[int, str]]]] = None,
    ) -> Dict[str, Any]:
        """
        Paginated read with count. Returns envelope:
          { ok, total, page, page_size, results: [...] }
        """
        q = _sanitize_filter(query or {})
        page = max(1, page)
        page_size = max(1, min(int(page_size), MAX_PAGE_SIZE))
        skip = (page - 1) * page_size

        try:
            total = self.collection.count_documents(q)
            cursor = self.collection.find(q, projection=projection)
            if sort:
                cursor = cursor.sort(_coerce_sort(sort))
            cursor = cursor.skip(skip).limit(page_size)
            results = list(cursor)
            for d in results:
                d["_id"] = str(d["_id"])
            return {
                "ok": True,
                "total": total,
                "page": page,
                "page_size": page_size,
                "results": results,
            }
        except PyMongoError as e:
            logger.error("Paginated read failed: %s", e)
            return {"ok": False, "error": str(e), "total": 0, "page": page, "page_size": page_size, "results": []}

    def update(self, object_id: Union[str, ObjectId], update_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update by _id using $set. Returns {ok, modified_count}.
        """
        if not isinstance(update_data, dict) or not update_data:
            raise ValueError("update_data must be a non-empty dict.")
        _reject_dollar_keys(update_data)

        oid = _str_object_id(object_id)
        try:
            result = self.collection.update_one({"_id": oid}, {"$set": update_data})
            return {"ok": True, "modified_count": result.modified_count}
        except PyMongoError as e:
            logger.error("Update failed: %s", e)
            return {"ok": False, "error": str(e), "modified_count": 0}

    def delete(self, object_id: Union[str, ObjectId]) -> Dict[str, Any]:
        """
        Delete by _id. Returns {ok, deleted_count}.
        """
        oid = _str_object_id(object_id)
        try:
            result = self.collection.delete_one({"_id": oid})
            return {"ok": True, "deleted_count": result.deleted_count}
        except PyMongoError as e:
            logger.error("Delete failed: %s", e)
            return {"ok": False, "error": str(e), "deleted_count": 0}

    # -------------------------------------------------------------------------
    # Analytics / Convenience
    # -------------------------------------------------------------------------
    def read_grouped_by_breed_with_avg_age(self, base_query: Dict[str, Any] | None = None) -> Dict[str, float]:
        """
        Average age_upon_outcome_in_weeks per breed (desc).
        Returns {breed: avg_age} (rounded to 2 decimals).
        """
        q = _sanitize_filter(base_query or {})
        pipeline = [
            {"$match": q},
            {
                "$group": {
                    "_id": "$breed",
                    "avg_age": {"$avg": "$age_upon_outcome_in_weeks"},
                }
            },
            {"$sort": {"avg_age": -1}},
        ]
        try:
            results = self.collection.aggregate(pipeline)
            out: Dict[str, float] = {}
            for doc in results:
                breed = doc.get("_id")
                if breed:
                    out[breed] = round(float(doc.get("avg_age", 0.0)), 2)
            return out
        except PyMongoError as e:
            logger.error("Aggregation failed: %s", e)
            return {}

    def find_distinct_breeds(self) -> List[str]:
        """
        Returns sorted list of distinct breeds.
        """
        try:
            breeds = self.collection.distinct("breed")
            return sorted([b for b in breeds if isinstance(b, str)])
        except PyMongoError as e:
            logger.error("Distinct query failed: %s", e)
            return []

    def find_by_adoption_status(self, status: str = "Adopted", limit: int = 100) -> List[Dict[str, Any]]:
        """
        Convenience read for outcome_type.
        """
        try:
            return self.read({"outcome_type": status}, limit=limit)
        except Exception as e:
            logger.error("Status query failed: %s", e)
            return []

    def get_count_by_condition(self, condition: Dict[str, Any] | None = None) -> int:
        """
        Count documents matching sanitized condition.
        """
        q = _sanitize_filter(condition or {})
        try:
            return int(self.collection.count_documents(q))
        except PyMongoError as e:
            logger.error("Count failed: %s", e)
            return 0
