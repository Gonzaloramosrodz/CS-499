# app_enhanced.py — Dash app with Algorithms/DS ranking integrated
# - Env-based Mongo config (MONGO_URI or HOST/PORT/USER/PASS with DB/COL)
# - CSV fallback (aac_shelter_outcomes.csv) if DB unavailable
# - Table, pie chart, map
# - Ranking controls: heap-based Top-K + optional Pareto frontier

import os
import base64
from typing import Optional, List, Dict, Any

import pandas as pd
from dash import Dash, dcc, html, dash_table
from dash.dependencies import Input, Output, State
import dash_leaflet as dl
import plotly.express as px

from animal_shelter import AnimalShelter
from ranking import (
    default_config_for_animals,
    rank_top_k,
    pareto_frontier,
    ScoringConfig,
)

# -----------------------------------------------------------------------------
# Data access helpers
# -----------------------------------------------------------------------------
def _init_db() -> Optional[AnimalShelter]:
    """
    Initialize AnimalShelter using env-based configuration.
    Accepts MONGO_URI or MONGO_HOST/PORT/USER/PASS with MONGO_DB/MONGO_COL.
    Returns None if connection fails (app will use CSV fallback).
    """
    try:
        mongo_uri = os.getenv("MONGO_URI")
        if mongo_uri:
            return AnimalShelter(mongo_uri=mongo_uri)

        host = os.getenv("MONGO_HOST")
        port = os.getenv("MONGO_PORT")
        user = os.getenv("MONGO_USER")
        pwd = os.getenv("MONGO_PASS")
        db = os.getenv("MONGO_DB") or "AAC"
        col = os.getenv("MONGO_COL") or "animals"

        if host and port and user and pwd:
            return AnimalShelter(
                host=host,
                port=int(port),
                username=user,
                password=pwd,
                db_name=db,
                collection_name=col,
            )
    except Exception as e:
        print(f"[WARN] DB init failed: {e}")
    return None


def _read_records(db: Optional[AnimalShelter], query: Optional[Dict[str, Any]] = None, limit: int = 500) -> List[Dict[str, Any]]:
    """
    Pull records from DB if available; otherwise return [] (caller can fallback to CSV).
    """
    if db is None:
        return []
    try:
        return db.read(query or {}, limit=limit)
    except Exception as e:
        print(f"[WARN] DB read failed: {e}")
        return []


def _load_csv_fallback(path: str = "aac_shelter_outcomes.csv") -> pd.DataFrame:
    """
    CSV fallback for local/offline use. Also tries to normalize lat/long column names.
    """
    try:
        df_csv = pd.read_csv(path)
    except Exception as e:
        print(f"[WARN] CSV fallback load failed: {e}")
        return pd.DataFrame()

    # Normalize geo columns if needed
    if "location_lat" not in df_csv.columns:
        for alt_lat in ("latitude", "lat"):
            if alt_lat in df_csv.columns:
                df_csv["location_lat"] = df_csv[alt_lat]
                break
    if "location_long" not in df_csv.columns:
        for alt_lon in ("longitude", "lon", "long"):
            if alt_lon in df_csv.columns:
                df_csv["location_long"] = df_csv[alt_lon]
                break

    # If length_of_stay_in_weeks is missing, create a placeholder
    if "length_of_stay_in_weeks" not in df_csv.columns:
        df_csv["length_of_stay_in_weeks"] = pd.NA

    return df_csv


def _to_dataframe(records: List[Dict[str, Any]], csv_fallback: pd.DataFrame) -> pd.DataFrame:
    """
    Convert DB records to DataFrame; drop _id; if empty, use CSV fallback.
    """
    if records:
        df = pd.DataFrame.from_records(records)
        df = df.drop(columns=["_id"], errors="ignore")
        if "length_of_stay_in_weeks" not in df.columns:
            df["length_of_stay_in_weeks"] = pd.NA
        return df
    return csv_fallback.copy()


# -----------------------------------------------------------------------------
# Bootstrap data
# -----------------------------------------------------------------------------
DB = _init_db()
CSV_FALLBACK = _load_csv_fallback()

INITIAL_DF = _to_dataframe(_read_records(DB, {}, limit=500), CSV_FALLBACK)
if INITIAL_DF.empty:
    INITIAL_DF = pd.DataFrame(
        columns=[
            "name",
            "breed",
            "outcome_type",
            "age_upon_outcome_in_weeks",
            "length_of_stay_in_weeks",
            "location_lat",
            "location_long",
        ]
    )

# Logo (optional)
def _load_logo(path: str = "grazioso_salvare_logo.png") -> Optional[str]:
    try:
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode("utf-8")
    except Exception:
        return None

LOGO_B64 = _load_logo()

# Rescue filter definitions
RESCUE_MAP = {
    "Water Rescue": ["Labrador Retriever", "Chesapeake Bay Retriever", "Newfoundland"],
    "Mountain or Wilderness Rescue": [
        "German Shepherd",
        "Alaskan Malamute",
        "Old English Sheepdog",
        "Siberian Husky",
    ],
    "Disaster Rescue or Individual Tracking": [
        "German Shepherd",
        "Doberman Pinscher",
        "Bloodhound",
        "Rottweiler",
    ],
}

# -----------------------------------------------------------------------------
# Dash app
# -----------------------------------------------------------------------------
app = Dash(__name__)

def layout():
    return html.Div(
        [
            html.Center(html.B(html.H1("CS-340 / CS-499 Animal Outcomes Dashboard"))),
            (html.Img(
                src=f"data:image/png;base64,{LOGO_B64}",
                style={"height": "90px", "margin": "10px"},
            ) if LOGO_B64 else html.Div()),
            html.H6("Dashboard by Gonzalo Ramos"),
            html.Hr(),

            # Rescue type filters
            html.Div(
                [
                    dcc.RadioItems(
                        id="filter-type",
                        options=[
                            {"label": "Water Rescue", "value": "Water Rescue"},
                            {
                                "label": "Mountain or Wilderness Rescue",
                                "value": "Mountain or Wilderness Rescue",
                            },
                            {
                                "label": "Disaster Rescue or Individual Tracking",
                                "value": "Disaster Rescue or Individual Tracking",
                            },
                            {"label": "Reset", "value": "Reset"},
                        ],
                        value="Reset",
                        labelStyle={"display": "inline-block", "marginRight": "15px"},
                        inputStyle={"marginRight": "6px"},
                    ),
                    dcc.Store(id="data-store"),  # store current table data
                ],
                style={"padding": "10px"},
            ),

            # Algorithms & Data Structures controls
            html.Fieldset(
                [
                    html.Legend("Ranking Controls (Algorithms & Data Structures)"),
                    html.Div(
                        [
                            html.Label("Top-K"),
                            dcc.Input(
                                id="rank-topk",
                                type="number",
                                min=1,
                                max=100,
                                value=10,
                                style={"width": "80px"},
                            ),
                            html.Label("Weight: Age (lower is better)"),
                            dcc.Slider(id="w-age", min=0, max=1, step=0.05, value=0.5),
                            html.Label("Weight: Length of stay (lower is better)"),
                            dcc.Slider(id="w-los", min=0, max=1, step=0.05, value=0.3),
                            html.Label("Weight: Breed bonus"),
                            dcc.Slider(id="w-breed", min=0, max=1, step=0.05, value=0.2),
                            dcc.Checklist(
                                id="use-pareto",
                                options=[
                                    {
                                        "label": "Apply Pareto frontier to current view before ranking",
                                        "value": "yes",
                                    }
                                ],
                                value=[],
                                style={"marginTop": "6px"},
                            ),
                        ],
                        style={"display": "grid", "gap": "8px"},
                    ),
                ]
            ),
            html.Div(id="ranked-output"),
            html.Hr(),

            # Main table
            dash_table.DataTable(
                id="datatable-id",
                columns=[{"name": c, "id": c} for c in INITIAL_DF.columns],
                data=INITIAL_DF.to_dict("records"),
                page_size=10,
                style_table={"overflowX": "auto"},
                style_cell={
                    "textAlign": "left",
                    "minWidth": "100px",
                    "maxWidth": "300px",
                    "whiteSpace": "normal",
                },
                style_header={"backgroundColor": "rgb(230,230,230)", "fontWeight": "bold"},
                row_selectable="single",
                sort_action="native",
                filter_action="native",
            ),

            # Charts + Map
            html.Div(
                className="row",
                style={"display": "flex", "marginTop": "20px"},
                children=[
                    html.Div(id="graph-id", className="col s12 m6", style={"width": "50%"}),
                    html.Div(id="map-id", className="col s12 m6", style={"width": "50%"}),
                ],
            ),
        ]
    )

app.layout = layout

# -----------------------------------------------------------------------------
# Callbacks
# -----------------------------------------------------------------------------
@app.callback(
    Output("datatable-id", "data"),
    Output("datatable-id", "columns"),
    Output("data-store", "data"),
    Input("filter-type", "value"),
)
def update_table(filter_type: str):
    """
    Update table rows (and column schema) based on filter selection.
    Prefers DB; if no records, falls back to CSV.
    """
    try:
        if filter_type == "Reset":
            records = _read_records(DB, {}, limit=500)
        else:
            breeds = RESCUE_MAP.get(filter_type, [])
            query = {
                "breed": {"$in": breeds},
                "age_upon_outcome_in_weeks": {"$lte": 104},
            }
            records = _read_records(DB, query, limit=500)

        df = _to_dataframe(records, CSV_FALLBACK)
        cols = [{"name": c, "id": c} for c in df.columns]
        return df.to_dict("records"), cols, df.to_dict("records")
    except Exception as e:
        print(f"[WARN] update_table error: {e}")
        df = INITIAL_DF.copy()
        cols = [{"name": c, "id": c} for c in df.columns]
        return df.to_dict("records"), cols, df.to_dict("records")


@app.callback(
    Output("graph-id", "children"),
    Input("data-store", "data"),
)
def update_graphs(view_data):
    """
    Pie chart of preferred breeds in current table view.
    """
    try:
        dff = pd.DataFrame(view_data) if view_data else INITIAL_DF
        if "breed" in dff.columns and not dff.empty:
            fig = px.pie(dff, names="breed", title="Preferred Breeds (current filter)")
            return [dcc.Graph(figure=fig)]
        return [html.P("No data available for chart.")]
    except Exception as e:
        print(f"[WARN] update_graphs error: {e}")
        return [html.P("Chart unavailable.")]


@app.callback(
    Output("datatable-id", "style_data_conditional"),
    Input("datatable-id", "selected_columns"),
)
def highlight_columns(selected_columns):
    if not selected_columns:
        return []
    return [{"if": {"column_id": c}, "background_color": "#D2F3FF"} for c in selected_columns]


@app.callback(
    Output("map-id", "children"),
    Input("datatable-id", "derived_virtual_data"),
    Input("datatable-id", "derived_virtual_selected_rows"),
    State("data-store", "data"),
)
def update_map(virtual_data, selected_rows, backing_store):
    """
    Show map marker for the selected row.
    Uses columns: location_lat, location_long, breed, name (if present).
    """
    try:
        rows = virtual_data if virtual_data is not None else backing_store
        if not rows or not selected_rows:
            return html.Div()

        dff = pd.DataFrame(rows)
        row_idx = selected_rows[0]

        lat = float(dff.iloc[row_idx].get("location_lat"))
        lon = float(dff.iloc[row_idx].get("location_long"))
        breed = str(dff.iloc[row_idx].get("breed", "Unknown"))
        name = str(dff.iloc[row_idx].get("name", "Unknown"))

        if pd.isna(lat) or pd.isna(lon):
            return html.P("Invalid geolocation data.")

        return [
            dl.Map(
                style={"width": "100%", "height": "500px"},
                center=[lat, lon],
                zoom=12,
                children=[
                    dl.TileLayer(id="base-layer-id"),
                    dl.Marker(
                        position=[lat, lon],
                        children=[
                            dl.Tooltip(breed),
                            dl.Popup([html.H4("Animal Name"), html.P(name)]),
                        ],
                    ),
                ],
            )
        ]
    except Exception as e:
        print(f"[WARN] update_map error: {e}")
        return html.P("Map unavailable.")


# ---------- Algorithms & Data Structures: Ranking callback ----------
@app.callback(
    Output("ranked-output", "children"),
    Input("data-store", "data"),
    Input("rank-topk", "value"),
    Input("w-age", "value"),
    Input("w-los", "value"),
    Input("w-breed", "value"),
    Input("use-pareto", "value"),
)
def compute_ranking(view_data, k, w_age, w_los, w_breed, use_pareto):
    """
    Heap-based Top-K ranking with optional Pareto frontier filter.
    """
    try:
        rows = view_data or []
        if not rows:
            return html.P("No data to rank.")

        # Optional Pareto filter on two numeric metrics (lower is better)
        records = rows
        if "yes" in (use_pareto or []):
            metrics = [
                ("age_upon_outcome_in_weeks", False),
                ("length_of_stay_in_weeks", False),
            ]
            records = pareto_frontier(rows, metrics)

        # Build scoring config from sliders
        cfg: ScoringConfig = default_config_for_animals(
            weight_age_low_is_better=float(w_age or 0.0),
            weight_length_stay_low_is_better=float(w_los or 0.0),
            weight_breed_bonus=float(w_breed or 0.0),
        )

        topk = int(k or 10)
        ranked = rank_top_k(records, cfg, k=topk)
        if not ranked:
            return html.P("No ranked results.")

        out_rows = []
        for score, rec in ranked:
            out_rows.append(
                {
                    "score": round(float(score), 4),
                    "name": rec.get("name"),
                    "breed": rec.get("breed"),
                    "age_weeks": rec.get("age_upon_outcome_in_weeks"),
                    "length_of_stay_in_weeks": rec.get("length_of_stay_in_weeks"),
                }
            )
        rdf = pd.DataFrame(out_rows)

        table = dash_table.DataTable(
            columns=[{"name": c, "id": c} for c in rdf.columns],
            data=rdf.to_dict("records"),
            page_size=min(len(rdf), 10),
            style_table={"overflowX": "auto"},
            style_header={"backgroundColor": "rgb(230,230,230)", "fontWeight": "bold"},
        )

        fig = px.bar(rdf, x="name", y="score", title="Top-K Ranked Candidates")
        graph = dcc.Graph(figure=fig)

        return html.Div([table, html.Br(), graph])

    except Exception as e:
        print(f"[WARN] compute_ranking error: {e}")
        return html.P("Ranking unavailable.")

# -----------------------------------------------------------------------------
# Entrypoint
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    app.run_server(host="0.0.0.0", port=int(os.getenv("PORT", "8050")), debug=True)
