# ranking.py — Algorithms & Data Structures enhancement for CS 499
# - Multi-criteria Top-K ranking using a min-heap (heapq)
# - Optional Pareto frontier filter (non-dominated set)
# - Normalization and flexible feature weighting
#
# Time complexity:
#   - Scoring: O(n)
#   - Top-K via heap: O(n log k)  (k << n recommended)
#   - Pareto frontier (pairwise): O(n^2) worst-case (use on filtered sets)

from __future__ import annotations
from typing import Any, Dict, Iterable, List, Tuple, Callable, Optional
import math
import heapq
import pandas as pd

Number = float | int

# -----------------------------
# Feature extraction utilities
# -----------------------------
def _is_number(x: Any) -> bool:
    try:
        float(x)
        return True
    except Exception:
        return False

def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default

def _min_max(series: Iterable[Number]) -> tuple[float, float]:
    vals = [float(v) for v in series if _is_number(v)]
    if not vals:
        return (0.0, 1.0)
    return (min(vals), max(vals))

def _normalize(value: Any, vmin: float, vmax: float, higher_is_better: bool = True) -> float:
    """Return value in [0,1]. If higher_is_better=False, invert the scale."""
    x = _safe_float(value, 0.0)
    if math.isclose(vmin, vmax):
        norm = 0.0
    else:
        norm = (x - vmin) / (vmax - vmin)
    return norm if higher_is_better else (1.0 - norm)

# -----------------------------
# Scoring config
# -----------------------------
class ScoringConfig:
    """
    Define how records are scored:
      - numeric_features: dict[name] = (higher_is_better: bool)
      - categorical_bonuses: dict[name] = dict[value] = bonus in [0,1]
      - weights: dict[name] = weight (non-negative). Weights are re-normalized.
    """
    def __init__(
        self,
        numeric_features: Dict[str, bool],
        categorical_bonuses: Dict[str, Dict[Any, float]] | None = None,
        weights: Dict[str, float] | None = None
    ):
        self.numeric_features = numeric_features
        self.categorical_bonuses = categorical_bonuses or {}
        # default equal weights if not provided
        if weights:
            self.weights = {k: float(v) for k, v in weights.items()}
        else:
            all_keys = list(numeric_features.keys()) + list(self.categorical_bonuses.keys())
            self.weights = {k: 1.0 for k in all_keys}

        # normalize weights to sum 1
        s = sum(w for w in self.weights.values() if w >= 0)
        if s <= 0:
            # fallback to equal weights
            n = max(1, len(self.weights))
            self.weights = {k: 1.0 / n for k in self.weights.keys()}
        else:
            self.weights = {k: (max(0.0, w) / s) for k, w in self.weights.items()}

# -----------------------------
# Scoring pipeline
# -----------------------------
def compute_feature_ranges(records: Iterable[Dict[str, Any]], config: ScoringConfig) -> Dict[str, Tuple[float, float]]:
    """
    Determine min/max for numeric features across the records (for normalization).
    """
    df = pd.DataFrame(records)
    ranges: Dict[str, Tuple[float, float]] = {}
    for feat in config.numeric_features.keys():
        col = df[feat] if feat in df.columns else []
        vmin, vmax = _min_max(col)
        ranges[feat] = (vmin, vmax)
    return ranges

def score_record(
    rec: Dict[str, Any],
    config: ScoringConfig,
    ranges: Dict[str, Tuple[float, float]],
) -> float:
    """
    Weighted score in [0, 1+sum(bonuses)]:
      - numeric features are min-max normalized
      - categorical bonuses are added linearly (bounded to non-negative)
    """
    score = 0.0

    # numeric
    for feat, higher_is_better in config.numeric_features.items():
        vmin, vmax = ranges.get(feat, (0.0, 1.0))
        val = rec.get(feat)
        s = _normalize(val, vmin, vmax, higher_is_better=higher_is_better)
        weight = config.weights.get(feat, 0.0)
        score += weight * s

    # categorical bonuses
    for feat, mapping in config.categorical_bonuses.items():
        val = rec.get(feat)
        bonus = float(mapping.get(val, 0.0))
        weight = config.weights.get(feat, 0.0)
        score += weight * max(0.0, bonus)

    return float(score)

def rank_top_k(
    records: Iterable[Dict[str, Any]],
    config: ScoringConfig,
    k: int = 10,
    *,
    ranges: Dict[str, Tuple[float, float]] | None = None
) -> List[Tuple[float, Dict[str, Any]]]:
    """
    Return top-k records by score using a min-heap. Complexity O(n log k).
    Output: list of (score, record) sorted by descending score.
    """
    recs = list(records)
    if not recs or k <= 0:
        return []

    ranges = ranges or compute_feature_ranges(recs, config)
    heap: List[Tuple[float, int, Dict[str, Any]]] = []  # (score, idx, rec)

    for idx, rec in enumerate(recs):
        s = score_record(rec, config, ranges)
        if len(heap) < k:
            heapq.heappush(heap, (s, idx, rec))
        else:
            if s > heap[0][0]:
                heapq.heapreplace(heap, (s, idx, rec))

    # Convert to sorted list (descending by score)
    results = sorted([(s, r) for (s, _, r) in heap], key=lambda t: t[0], reverse=True)
    return results

# -----------------------------
# Pareto frontier (optional)
# -----------------------------
def pareto_frontier(
    records: Iterable[Dict[str, Any]],
    metrics: List[Tuple[str, bool]],
) -> List[Dict[str, Any]]:
    """
    Compute non-dominated set (Pareto frontier).
    metrics: list of (field, higher_is_better)
    A record A dominates B if A is >= B in all metrics and > in at least one.
    Complexity: O(n^2) worst-case. Use on filtered sets (e.g., top-k).
    """
    recs = list(records)
    frontier: List[Dict[str, Any]] = []

    def dominates(a: Dict[str, Any], b: Dict[str, Any]) -> bool:
        ge_all = True
        gt_any = False
        for field, hib in metrics:
            av = _safe_float(a.get(field), 0.0)
            bv = _safe_float(b.get(field), 0.0)
            if hib:   # higher is better
                if av < bv:
                    ge_all = False
                    break
                if av > bv:
                    gt_any = True
            else:     # lower is better
                if av > bv:
                    ge_all = False
                    break
                if av < bv:
                    gt_any = True
        return ge_all and gt_any

    for i, r in enumerate(recs):
        dominated = False
        to_remove = []
        for j, f in enumerate(frontier):
            if dominates(f, r):
                dominated = True
                break
            if dominates(r, f):
                to_remove.append(j)
        if not dominated:
            # remove any frontier members dominated by r
            for j in reversed(to_remove):
                frontier.pop(j)
            frontier.append(r)
    return frontier

# -----------------------------
# Convenience for your dataset
# -----------------------------
def default_config_for_animals(
    weight_age_low_is_better: float = 0.5,
    weight_length_stay_low_is_better: float = 0.3,
    weight_breed_bonus: float = 0.2,
) -> ScoringConfig:
    """
    Example config for AAC:
      - Younger age and shorter length of stay preferred (lower is better)
      - Breed bonuses for rescue suitability
    """
    numeric = {
        "age_upon_outcome_in_weeks": False,   # lower is better
        "length_of_stay_in_weeks": False,     # if present; lower is better
    }
    categorical = {
        "breed": {
            # example rescue-suitable bonuses (0..1)
            "Labrador Retriever": 1.0,
            "Chesapeake Bay Retriever": 0.9,
            "Newfoundland": 0.8,
            "German Shepherd": 0.8,
            "Alaskan Malamute": 0.6,
            "Siberian Husky": 0.6,
            "Old English Sheepdog": 0.6,
            "Doberman Pinscher": 0.5,
            "Bloodhound": 0.5,
            "Rottweiler": 0.4,
        }
    }
    weights = {
        "age_upon_outcome_in_weeks": weight_age_low_is_better,
        "length_of_stay_in_weeks": weight_length_stay_low_is_better,
        "breed": weight_breed_bonus,
    }
    return ScoringConfig(numeric_features=numeric, categorical_bonuses=categorical, weights=weights)

def rank_animals_top_k(
    records: Iterable[Dict[str, Any]],
    k: int = 10,
    *,
    config: Optional[ScoringConfig] = None
) -> List[Tuple[float, Dict[str, Any]]]:
    """
    One-liner to rank animals with default config.
    """
    cfg = config or default_config_for_animals()
    return rank_top_k(records, cfg, k=k)
