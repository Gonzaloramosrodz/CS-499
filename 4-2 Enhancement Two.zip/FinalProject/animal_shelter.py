# animal_shelter.py - Fully Enhanced for CS 499

from pymongo import MongoClient
from bson.objectid import ObjectId
import os

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, username=None, password=None):
        """
        Initializes connection to MongoDB using provided or environment credentials.
        """
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31359
        DB = 'AAC'
        COL = 'animals'

        # Load from environment variables if not passed directly
        self.username = username or os.getenv('MONGO_USER', 'aacuser')
        self.password = password or os.getenv('MONGO_PASS', 'SNHU1234')

        # Initialize MongoDB client
        self.client = MongoClient(f'mongodb://{self.username}:{self.password}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Inserts a new document into the collection.
        Returns True if successful, False otherwise.
        """
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Insert failed: {e}")
                return False
        else:
            raise ValueError("Data parameter is empty")

    def read(self, query):
        """
        Reads documents from the collection based on the given query.
        Returns a list of documents.
        """
        try:
            return list(self.collection.find(query))
        except Exception as e:
            print(f"Read failed: {e}")
            return []

    def read_all(self):
        """
        Reads all documents from the collection.
        Returns a list of documents.
        """
        try:
            return list(self.collection.find())
        except Exception as e:
            print(f"Read all failed: {e}")
            return []

    def read_grouped_by_breed_with_avg_age(self, base_query):
        """
        Performs a grouped MongoDB aggregation to calculate average age
        upon outcome (in weeks) for each breed matching the base query.
        Returns a dictionary in the format {breed: avg_age}.
        """
        try:
            pipeline = [
                {"$match": base_query},
                {"$group": {
                    "_id": "$breed",
                    "avg_age": {"$avg": "$age_upon_outcome_in_weeks"}
                }},
                {"$sort": {"avg_age": -1}}
            ]
            results = self.collection.aggregate(pipeline)
            return {doc["_id"]: doc["avg_age"] for doc in results if doc["_id"] is not None}
        except Exception as e:
            print(f"Aggregation failed: {e}")
            return {}
